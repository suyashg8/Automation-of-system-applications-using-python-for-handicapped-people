from pyautogui import *
import serial
from os import *
from threading import Thread
from time import *
import docx
import webbrowser
from PIL import Image
import pyautogui
from googlesearch import search
import cv2
import pyttsx3


ser3=serial.Serial("COM3",9600)
finish=False
engine = pyttsx3.init()
engine.say("hello guys! welcome to the voice operated system. ")
engine.runAndWait()


mouse_controls_list = ['enable mouse usage','enable mouse control','start mouse usage','start mouse control', 'enable the mouse control', 'enable a mouse control','start the mouse control']
presentation_list=['open a presentation', 'open presentation', 'open the presentation']
search_list =['i want to search' , 'start search', 'choose search','select search','search']
screenshot_list=['take a screenshot','take screenshot', 'take the screenshot', 'click a screenshot','click screenshot','click the screenshot']
website_list=['open a website', 'open website','launch website','open the website','launch the website','launch a website']
browser_list=['open web browser','open browser','open a browser','open the browser','open the web browser','open a web browser']
read_word=['read a word file','read the word file','read word file']
take_picture=['take picture','take a picture','take the picture','click picture','click a picture']
create_word=['create a word file','create word file','create the word file','make a word file','make word file']

def mouse_control():
    print("mouse control enabled")
    engine.say("mouse control enabled")
    engine.runAndWait()
    
    Finish=True
    while Finish:
        t=ser3.readline().strip().decode('utf-8')
        print(t)
        t=t.replace("*",'')
        t=t.replace("#",'')
        print(t)
        words=t.split()
        if t=="left click":
            click()
        if t=="double click":
            doubleClick()
        if t=="right click":
            rightClick()
        if t=="done":
            Finish=False

        if t=="up":
            pyautogui.moveRel(0, -100, duration = 1)
        if t=="down":
            pyautogui.moveRel(0, 100, duration = 1)
        if t=="right":
            pyautogui.moveRel(100,0, duration = 1)
        if t=="left":
            pyautogui.moveRel(-100,0, duration = 1)
        if t=="slightly up":
            pyautogui.moveRel(0, -30, duration = 1)
        if t=="slightly down":
            pyautogui.moveRel(0, 30, duration = 1)
        if t=="slightly right":
            pyautogui.moveRel(30,0, duration = 1)
        if t=="slightly left":
            pyautogui.moveRel(-30,0, duration = 1)
        if t=="right diagonal up":
            pyautogui.moveRel(100, -100, duration = 1)
        if t=="right diagonal down":
            pyautogui.moveRel(100, 100, duration = 1)
        if t=="left diagonal up":
            pyautogui.moveRel(-100,100, duration = 1)
        if t=="left diagoanl down":
            pyautogui.moveRel(-100,0, duration = 1)
        if t=="top":
            pyautogui.moveTo(950,0, duration = 1)
        if t=="bottom":
            pyautogui.moveTo(950, 1050, duration = 1)
        if t=="extreme left":
            pyautogui.moveTo(0,500, duration = 1)
        if t=="extreme right":
            pyautogui.moveRel(1500,500, duration = 1)
        if t=="top left corner":
            pyautogui.moveTo(0,0, duration = 1)
        if t=="bottom left corner":
            pyautogui.moveTo(0,1070 , duration = 1)
        if t=="top right corner":
            pyautogui.moveTo(1900,0, duration = 1)
        if t=="bottom right corner":
            pyautogui.moveTo(1900,1070 , duration = 1)


    print("Mouse control disabled")
    engine.say("mouse control disabled")
    engine.runAndWait()
    

    
def close():
    hotkey("alt","f4")

    
def scrolldown():
    for i in range (0,8):
        pyautogui.press('down')


def next_link():
     for i in range (0,11):
         pyautogui.press("tab")
     link=True
     
     while link:
         t=ser3.readline().strip().decode('utf-8')
         t=t.replace("*",'')
         t=t.replace("#",'')
         name=t.lower()
         if(t.lower()=="next link"):
             pyautogui.press("tab")
         if t.lower()=="done":
             link=False
         if t.lower()=="launch link":
             pyautogui.press("enter")
         if name in mouse_controls_list:
             mouse_control()
    
def scrollup():
    for i in range (0,8):
        pyautogui.press('up')
            
def screenshot():
    im = pyautogui.screenshot()
    print("enter a name for the screenshot")
    engine.say("enter a name for the screenshot")
    engine.runAndWait()

    t=ser3.readline().strip().decode('utf-8')
    t=t.replace("*",'')
    t=t.replace("#",'')
    print(t)
    name=t
    im.save(t+'.png')
    print("Do you want to open the screenshot file?")
    print("Yes or No?")
    t=ser3.readline().strip().decode('utf-8')
    t=t.replace("*",'')
    t=t.replace("#",'')
    print(t)
    if(t.lower()=="yes"):
        try:  
            engine.say("opening the screenshot file")
            engine.runAndWait()

            startfile(name+".png")  
        except IOError: 
            print("File does not exist..")
    if(t.lower()=="no"):
        print("File saved")
    print("File saved")
    sleep(10)
    close()
    
def scroll():
    pyautogui.scroll(1000)


while True:
    t=ser3.readline().strip().decode('utf-8')
    t=t.replace("*",'')
    t=t.replace("#",'')
    print(t)
    t=t.lower()
    command=""
    command=t
    print(type(command))
    if command in screenshot_list:
        screenshot()
    
    if command in presentation_list:
            print("Enter the name of the presentation")
            t=ser3.readline().strip().decode('utf-8')
            t=t.replace("*",'')
            t=t.replace("#",'')
            name=t    
            startfile(name+".pptx")
            engine.say("opening presentation")
            engine.runAndWait()

            sleep(6);
            finish2=False
            hotkey("fn","f5")
            while not finish2:
                t=ser3.readline().strip().decode('utf-8')
                t=t.replace("*",'')
                t=t.replace("#",'')
                if t.lower()=="next":
                    typewrite("\n",interval=0.001)
                elif t.lower()=="back":
                    typewrite("\b",interval=0.001)
                elif t.lower()=="close presentation":
                    hotkey("alt","f4")
                    hotkey("alt","f4")
                    finish2=True
                    engine.say("closing")
                    engine.runAndWait()

                    print("Presentation ended")
    
    if command in take_picture:
        sleep(5)
        camera = cv2.VideoCapture(0)
        return_value, image = camera.read()
        cv2.imwrite('pic.png', image)
        print("The photo is saved")
        engine.say("The photo is saved")
        engine.runAndWait()
    
        del(camera)
            

    if t.lower()=="close":
        close()
        

    
    if command in browser_list:
        print("Enter what do you want to do:")
        print("Search   or   open a website")
        
        t=ser3.readline().strip().decode('utf-8')
        t=t.replace("*",'')
        t=t.replace("#",'')
        print(t)
        command=""
        command=t.lower()
        if(command in search_list):
            t=ser3.readline().strip().decode('utf-8')
            t=t.replace("*",'')
            t=t.replace("#",'')
            print(t)
            name=t        
            google =name
            engine.say("Opening web browser")
            engine.runAndWait()
    
            webbrowser.open_new_tab('http://www.google.com/search?btnG=1&q=%s' % google)
            sleep(10)
            looking=True
            while looking:
                t=ser3.readline().strip().decode('utf-8')
                t=t.replace("*",'')
                t=t.replace("#",'')
                name=t.lower()
                if( t=="scroll up"):
                    scrollup()
                if(t=="scroll down"):
                    scrolldown()
                if(t=="done"):
                    looking=False
                    hotkey("alt","f4")
                if name in mouse_controls_list:
                    mouse_control()                    
                if(t=="next link"):
                   next_link()
            p=1
            close()
                    
            
        if(command in website_list):
            print("Enter the name of the website")
            t=ser3.readline().strip().decode('utf-8')
            t=t.replace("*",'')
            t=t.replace("#",'')
            web=t
            engine.say("Opening web browser")
            engine.runAndWait()
    
            webbrowser.open_new_tab('http://www.'+web)
            sleep(10)
            looking=True
            while looking:
                t=ser3.readline().strip().decode('utf-8')
                t=t.replace("*",'')
                t=t.replace("#",'')
                name=""
                name=t.lower()
                if( t=="scroll up"):
                    scrollup()
                if(t=="scroll down"):
                    scrolldown()
                if(t=="done"):
                    looking=False
                    hotkey("alt","f4")
                if name in mouse_controls_list:
                    mouse_control()
            
        
    if command in read_word:
        print(t)
        print("Enter the name of the documnet")
        t=ser3.readline().strip().decode('utf-8')
        t=t.replace("*",'')
        t=t.replace("#",'')
        name=t
        print(t)
        doc = docx.Document(name+'.docx')
        l=len(doc.paragraphs)
        for i in range(0,l):
            print(doc.paragraphs[i].text)
            engine.say(doc.paragraphs[i].text)
            engine.runAndWait()
    
        print("")
        print("End of File")
        engine.say("End Of File")
        engine.runAndWait()
    

        
    if command in mouse_controls_list:
            mouse_control()        
            

        
    if command in create_word:
        print(t)
        countpara=0
        print("Enter the name of the documnet")
        t=ser3.readline().strip().decode('utf-8')
        t=t.replace("*",'')
        t=t.replace("#",'')
        name=t        
        print(t)
        t=ser3.readline().strip().decode('utf-8')
        t=t.replace("*",'')
        t=t.replace("#",'')
        if t.lower()=="start typing":
            print(t)
            doc=docx.Document()
            sentence=""
            while not finish:
                t=ser3.readline().strip().decode('utf-8')
                t=t.replace("*",'')
                t=t.replace("#",'')
                print(t)
                if(t.lower()=="stop typing"):
                    finish=True

                if(t.lower()=="add heading"):
                    print("Enter the heading")
                    t=ser3.readline().strip().decode('utf-8')
                    t=t.replace("*",'')
                    t=t.replace("#",'')
                    print(t)
                    str=t+"\n"
                    doc.add_heading(str,0)

                    
                if(t.lower()=="next page"):
                     doc.add_paragraph(sentence)
                     sentence=""
                     doc.paragraphs[countpara].runs[0].add_break(docx.enum.text.WD_BREAK.PAGE)
                else:
                    tem1=t
                    tem1=tem1.replace("full stop",".")
                    tem1=tem1.replace("comma",",")
                    tem1=tem1.replace("next line","\n")
                    tem1=tem1.replace("question mark","?")
                    tem1=tem1.replace("tab","   ")
                    sentence=sentence+tem1
                    typewrite(tem1+"\n",interval=0.001)


            doc.add_paragraph(sentence)
            sentence=""
            doc.save(name+'.docx')
    if t.lower()=="close application":
        hotkey("alt","f4")
    if t.lower()=="goodbye":
        break
    else:
        print("Sorry, i dont understand")
        engine.say("Sorry, i dont understand")
        engine.runAndWait()
    
        
    finish=False

hotkey("alt","c")
hotkey("alt","f4")
